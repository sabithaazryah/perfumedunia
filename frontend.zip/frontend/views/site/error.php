<?php
/* @var $this yii\web\View */
/* @var $name string */
/* @var $message string */
/* @var $exception Exception */

use yii\helpers\Html;

$this->title = 'error';
?>
<section style="overflow: hidden;" bgcolor="#FFFFFF" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
        <a href="<?= Yii::$app->homeUrl ?>"><img src="<?= Yii::$app->homeUrl; ?>images/404.jpg" width="100%" height="auto" alt=""></a>
</section>
